#ifndef __myControl_H
#define __myControl_H	 

void Home1(void);
void Home2(void);
void Home_M(void);
void Home_F(void);
	 				    
#endif

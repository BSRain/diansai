#ifndef __myKEY_H
#define __myKEY_H

void Key_Init(void);
void KEY_number(void);

#endif

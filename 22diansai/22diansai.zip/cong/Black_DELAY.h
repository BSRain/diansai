/*
 * Black_DELAY.h
 *
 *  Created on: 2020��10��8��
 *      Author: PC
 */

#ifndef GO_BLACK_DELAY_H_
#define GO_BLACK_DELAY_H_

#include <msp430.h>
void delay_nms(int ms);
void delay_nus(int us);
void delay(int ms);        //��ʱ����

#endif /* GO_BLACK_DELAY_H_ */

#ifndef __myGrayscale_H
#define __myGrayscale_H	 

void Grayscale_Init(void);
	 			    
#endif

#ifndef __myUsart_H
#define __myUsart_H	 
#include "sys.h"

void USART1_Init(uint32_t bound);
	 				    
#endif
